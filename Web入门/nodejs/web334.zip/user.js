module.exports = {
  items: [
    {username: 'CTFSHOW', password: '123456'}
  ]
};